export default {
    products: [
        {
          _id: '1',
          name: 'NOUROU DARAYNI',
          category: 'Xassidas',
          image: '/images/d1.jpg',
          price: 100,
          brand: ' Xassida',
          
        },
        {
          _id: '2',
          name: 'DIALIBATOU MARAKHIBI',
          category: 'Xassidas',
          image: '/images/d2.jpg',
          price: 70,
          brand: ' Xassida',
          
        },
        {
          _id: '3',
          name: 'TAYSIROUL HANSSIR',
          category: 'Xassidas',
          image: '/images/d3.jpg',
          price: 60,
          brand: ' Xassida',
          
        }, {
          _id: '4',
          name: 'BISMILLAH-IKFINI',
          category: 'Xassidas',
          image: '/images/d4.jpg',
          price: 20,
          brand: ' Nike',
          
        }, {
            _id: '5',
            name: 'WALAKHAD KARAMNA',
            category: 'Xassidas',
            image: '/images/d4.jpg',
            price: 20,
            brand: ' Xassida',
            
          }, {
            _id: '6',
            name: 'MAFATIHOUL BICHRI',
            category: 'Xassidas',
            image: '/images/d4.jpg',
            price: 70,
            brand: ' Xassida',
            
          },

      ]
    }